package br.com.populacoes;

import android.content.Context;

import br.com.sqlite.dao.PerguntaDAO;
import br.com.sqlite.model.Pergunta;

public class PopularPotencia2 {

    public void popularPotencia2(Context context){

        Pergunta pergunta1 = new Pergunta();
        Pergunta pergunta2 = new Pergunta();
        Pergunta pergunta3 = new Pergunta();
        Pergunta pergunta4 = new Pergunta();
        Pergunta pergunta5 = new Pergunta();
        Pergunta pergunta6 = new Pergunta();
        Pergunta pergunta7 = new Pergunta();
        Pergunta pergunta8 = new Pergunta();
        Pergunta pergunta9 = new Pergunta();
        Pergunta pergunta10 = new Pergunta();
        PerguntaDAO perguntaDAO = new PerguntaDAO(context);

        pergunta1.preDados("Qual o resultado de 22²?", 3, 1, "400", "441", "484", "529", "Nenhuma das anteriores", 3);
        pergunta2.preDados("Qual o resultado de 47²?", 3, 2, "2209", "2500", "2025", "2304", "Nenhuma das anteriores", 1);
        pergunta3.preDados("Qual o resultado de 34²?", 3, 3, "1225", "1156", "900", "1089", "Nenhuma das anteriores", 2);
        pergunta4.preDados("Qual o resultado de 53²?", 3, 4, "2500", "2916", "2704", "2809", "Nenhuma das anteriores", 4);
        pergunta5.preDados("Qual o resultado de 17²?", 3, 5, "256", "324", "279", "225", "Nenhuma das anteriores", 5);
        pergunta6.preDados("Qual o resultado de 71²?", 3, 6, "4900", "5181", "4761", "5329", "Nenhuma das anteriores", 5);
        pergunta7.preDados("Qual o resultado de 60²?", 3, 7, "3900", "3480", "3720", "3600", "Nenhuma das anteriores", 4);
        pergunta8.preDados("Qual o resultado de 35²?", 3, 8, "900", "1225", "1600", "1325", "Nenhuma das anteriores", 2);
        pergunta9.preDados("Qual o resultado de 28²?", 3, 9, "784", "900", "841", "729", "Nenhuma das anteriores", 1);
        pergunta10.preDados("Qual o resultado de 65²?", 3, 10, "4096", "4355", "4225", "4489", "Nenhuma das anteriores", 3);

        perguntaDAO.gravar(pergunta1);
        perguntaDAO.gravar(pergunta2);
        perguntaDAO.gravar(pergunta3);
        perguntaDAO.gravar(pergunta4);
        perguntaDAO.gravar(pergunta5);
        perguntaDAO.gravar(pergunta6);
        perguntaDAO.gravar(pergunta7);
        perguntaDAO.gravar(pergunta8);
        perguntaDAO.gravar(pergunta9);
        perguntaDAO.gravar(pergunta10);

    }

}
