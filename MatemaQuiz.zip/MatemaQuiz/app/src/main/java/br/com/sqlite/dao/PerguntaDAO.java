package br.com.sqlite.dao;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import br.com.sqlite.model.Pergunta;
import br.com.sqlite.util.MySQLiteHelper;

public class PerguntaDAO {

    private SQLiteDatabase db = null;
    private MySQLiteHelper mySQLiteHelper = null;

    public PerguntaDAO(Context context) {
        mySQLiteHelper = new MySQLiteHelper(context);
    }

    public long gravar(Pergunta pergunta) throws SQLException {

        this.db = mySQLiteHelper.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put("titulo", pergunta.getTitulo());
        cv.put("cod_questionario", pergunta.getQuestionario());
        cv.put("numero_pergunta", pergunta.getNumeroPergunta());
        cv.put("a1", pergunta.getA1());
        cv.put("a2", pergunta.getA2());
        cv.put("a3", pergunta.getA3());
        cv.put("a4", pergunta.getA4());
        cv.put("a5", pergunta.getA5());
        cv.put("a_correta", pergunta.getA_correta());

        // 3. realizar o insert
        long retorno = db.insert("tb_pergunta", null, cv);

        // 4. fechar o banco e dar o retorno
        db.close();
        return retorno;
    }

    public Pergunta recuperarUm(int codPergunta) {
            Pergunta pergunta = null;

        String query = "SELECT  * FROM tb_pergunta WHERE cod_pergunta = " + codPergunta;

        this.db = mySQLiteHelper.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if (cursor != null){
            cursor.moveToFirst();
            pergunta = new Pergunta();
            pergunta.setCod_pergunta(Integer.parseInt(cursor.getString(0)));
            pergunta.setTitulo(cursor.getString(1));
            pergunta.setQuestionario(Integer.parseInt(cursor.getString(2)));
            pergunta.setNumeroPergunta(Integer.parseInt(cursor.getString(3)));
            pergunta.setA1(cursor.getString(4));
            pergunta.setA2(cursor.getString(5));
            pergunta.setA3(cursor.getString(6));
            pergunta.setA4(cursor.getString(7));
            pergunta.setA5(cursor.getString(8));
            pergunta.setA_correta(Integer.parseInt(cursor.getString(9)));

        }

        db.close();
        return pergunta;
    }

    public Pergunta selecao(int codQuestionario, int numeroPergunta) {
        Pergunta pergunta = null;

        String query = "SELECT  * FROM tb_pergunta WHERE cod_questionario = " + codQuestionario + " AND numero_pergunta = " + numeroPergunta;

        this.db = mySQLiteHelper.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if (cursor != null){
            cursor.moveToFirst();
            pergunta = new Pergunta();
            pergunta.setCod_pergunta(Integer.parseInt(cursor.getString(0)));
            pergunta.setTitulo(cursor.getString(1));
            pergunta.setQuestionario(Integer.parseInt(cursor.getString(2)));
            pergunta.setNumeroPergunta(Integer.parseInt(cursor.getString(3)));
            pergunta.setA1(cursor.getString(4));
            pergunta.setA2(cursor.getString(5));
            pergunta.setA3(cursor.getString(6));
            pergunta.setA4(cursor.getString(7));
            pergunta.setA5(cursor.getString(8));
            pergunta.setA_correta(Integer.parseInt(cursor.getString(9)));

        }

        db.close();
        return pergunta;
    }

}
