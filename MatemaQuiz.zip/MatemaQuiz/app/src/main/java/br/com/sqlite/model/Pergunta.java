package br.com.sqlite.model;

public class Pergunta {

    private int cod_pergunta;
    private String titulo;
    private int questionario;
    private int numeroPergunta;
    private String a1;
    private String a2;
    private String a3;
    private String a4;
    private String a5;
    private int a_correta;

    public Pergunta() {

    }

    public Pergunta(String titulo, int questionario, int numeroPergunta, String a1, String a2, String a3, String a4, String a5, int a_correta) {

        this.titulo = titulo;
        this.questionario = questionario;
        this.numeroPergunta = numeroPergunta;
        this.a1 = a1;
        this.a2 = a2;
        this.a3 = a3;
        this.a4 = a4;
        this.a5 = a5;
        this.a_correta = a_correta;

    }

    public Pergunta(int cod_pergunta, String titulo, int questionario, int numeroPergunta, String a1, String a2, String a3, String a4, String a5, int a_correta) {

        this.cod_pergunta = cod_pergunta;
        this.titulo = titulo;
        this.questionario = questionario;
        this.numeroPergunta = numeroPergunta;
        this.a1 = a1;
        this.a2 = a2;
        this.a3 = a3;
        this.a4 = a4;
        this.a5 = a5;
        this.a_correta = a_correta;

    }

    public int getCod_pergunta() {
        return cod_pergunta;
    }

    public void setCod_pergunta(int cod_pergunta) {
        this.cod_pergunta = cod_pergunta;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getQuestionario() {
        return questionario;
    }

    public void setQuestionario(int questionario) {
        this.questionario = questionario;
    }

    public int getNumeroPergunta() {
        return numeroPergunta;
    }

    public void setNumeroPergunta(int numeroPergunta) {
        this.numeroPergunta = numeroPergunta;
    }

    public String getA1() {
        return a1;
    }

    public void setA1(String a1) {
        this.a1 = a1;
    }

    public String getA2() {
        return a2;
    }

    public void setA2(String a2) {
        this.a2 = a2;
    }

    public String getA3() {
        return a3;
    }

    public void setA3(String a3) {
        this.a3 = a3;
    }

    public String getA4() {
        return a4;
    }

    public void setA4(String a4) {
        this.a4 = a4;
    }

    public String getA5() {
        return a5;
    }

    public void setA5(String a5) {
        this.a5 = a5;
    }

    public int getA_correta() {
        return a_correta;
    }

    public void setA_correta(int a_correta) {
        this.a_correta = a_correta;
    }

    public void preDados(String titulo, int questionario, int numeroPergunta, String a1, String a2, String a3, String a4, String a5, int a_correta){

        this.titulo = titulo;
        this.questionario = questionario;
        this.numeroPergunta = numeroPergunta;
        this.a1 = a1;
        this.a2 = a2;
        this.a3 = a3;
        this.a4 = a4;
        this.a5 = a5;
        this.a_correta = a_correta;

    }

}
