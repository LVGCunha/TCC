package br.com.populacoes;

import android.content.Context;

import br.com.sqlite.dao.PerguntaDAO;
import br.com.sqlite.model.Pergunta;

public class PopularSomaSubtracao {

    public void popularSomaSubtracao(Context context){

        Pergunta pergunta1 = new Pergunta();
        Pergunta pergunta2 = new Pergunta();
        Pergunta pergunta3 = new Pergunta();
        Pergunta pergunta4 = new Pergunta();
        Pergunta pergunta5 = new Pergunta();
        Pergunta pergunta6 = new Pergunta();
        Pergunta pergunta7 = new Pergunta();
        Pergunta pergunta8 = new Pergunta();
        Pergunta pergunta9 = new Pergunta();
        Pergunta pergunta10 = new Pergunta();
        PerguntaDAO perguntaDAO = new PerguntaDAO(context);

        pergunta1.preDados("Qual o resultado de 427 + 535?", 1, 1, "952", "953", "962", "963", "Nenhuma das anteriores", 3);
        pergunta2.preDados("Qual o resultado de 752 + 279?", 1, 2, "1031", "1021", "931", "921", "Nenhuma das anteriores", 1);
        pergunta3.preDados("Qual o resultado de 138 + 247?", 1, 3, "375", "385", "376", "386", "Nenhuma das anteriores", 2);
        pergunta4.preDados("Qual o resultado de 167 + 248?", 1, 4, "406", "416", "405", "415", "Nenhuma das anteriores", 4);
        pergunta5.preDados("Qual o resultado de 687 + 496?", 1, 5, "1084", "1082", "1182", "1184", "Nenhuma das anteriores", 5);
        pergunta6.preDados("Qual o resultado de 535 - 427?", 1, 6, "112", "109", "107", "102", "Nenhuma das anteriores", 5);
        pergunta7.preDados("Qual o resultado de 752 - 279?", 1, 7, "541", "543", "471", "473", "Nenhuma das anteriores", 4);
        pergunta8.preDados("Qual o resultado de 247 - 138?", 1, 8, "111", "109", "101", "119", "Nenhuma das anteriores", 2);
        pergunta9.preDados("Qual o resultado de 248 - 167?", 1, 9, "81", "91", "121", "181", "Nenhuma das anteriores", 1);
        pergunta10.preDados("Qual o resultado de 687 - 496?", 1, 10, "201", "111", "191", "291", "Nenhuma das anteriores", 3);

        perguntaDAO.gravar(pergunta1);
        perguntaDAO.gravar(pergunta2);
        perguntaDAO.gravar(pergunta3);
        perguntaDAO.gravar(pergunta4);
        perguntaDAO.gravar(pergunta5);
        perguntaDAO.gravar(pergunta6);
        perguntaDAO.gravar(pergunta7);
        perguntaDAO.gravar(pergunta8);
        perguntaDAO.gravar(pergunta9);
        perguntaDAO.gravar(pergunta10);

    }

}
