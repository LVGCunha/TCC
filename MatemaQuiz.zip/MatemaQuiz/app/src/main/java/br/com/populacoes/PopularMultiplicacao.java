package br.com.populacoes;

import android.content.Context;

import br.com.sqlite.dao.PerguntaDAO;
import br.com.sqlite.model.Pergunta;

public class PopularMultiplicacao {

    public void popularMultiplicacao(Context context){

        Pergunta pergunta1 = new Pergunta();
        Pergunta pergunta2 = new Pergunta();
        Pergunta pergunta3 = new Pergunta();
        Pergunta pergunta4 = new Pergunta();
        Pergunta pergunta5 = new Pergunta();
        Pergunta pergunta6 = new Pergunta();
        Pergunta pergunta7 = new Pergunta();
        Pergunta pergunta8 = new Pergunta();
        Pergunta pergunta9 = new Pergunta();
        Pergunta pergunta10 = new Pergunta();
        PerguntaDAO perguntaDAO = new PerguntaDAO(context);

        pergunta1.preDados("Qual o resultado de 115 x 22?", 2, 1, "2300", "2415", "2530", "2630", "Nenhuma das anteriores", 3);
        pergunta2.preDados("Qual o resultado de 12 x 87?", 2, 2, "1044", "957", "1080", "921", "Nenhuma das anteriores", 1);
        pergunta3.preDados("Qual o resultado de 123 x 24?", 2, 3, "2706", "2952", "2460", "3075", "Nenhuma das anteriores", 2);
        pergunta4.preDados("Qual o resultado de 165 x 13?", 2, 4, "1980", "2185", "2475", "2145", "Nenhuma das anteriores", 4);
        pergunta5.preDados("Qual o resultado de 107 x 17?", 2, 5, "1719", "1605", "2140", "1809", "Nenhuma das anteriores", 5);
        pergunta6.preDados("Qual o resultado de 71 x 94?", 2, 6, "6374", "7074", "6745", "6390", "Nenhuma das anteriores", 5);
        pergunta7.preDados("Qual o resultado de 56 x 60?", 2, 7, "3660", "2800", "3630", "3360", "Nenhuma das anteriores", 4);
        pergunta8.preDados("Qual o resultado de 40 x 35?", 2, 8, "1200", "1400", "1240", "1440", "Nenhuma das anteriores", 2);
        pergunta9.preDados("Qual o resultado de 17 x 13?", 2, 9, "221", "170", "255", "191", "Nenhuma das anteriores", 1);
        pergunta10.preDados("Qual o resultado de 207 x 45?", 2, 10, "10355", "11385", "9315", "8280", "Nenhuma das anteriores", 3);

        perguntaDAO.gravar(pergunta1);
        perguntaDAO.gravar(pergunta2);
        perguntaDAO.gravar(pergunta3);
        perguntaDAO.gravar(pergunta4);
        perguntaDAO.gravar(pergunta5);
        perguntaDAO.gravar(pergunta6);
        perguntaDAO.gravar(pergunta7);
        perguntaDAO.gravar(pergunta8);
        perguntaDAO.gravar(pergunta9);
        perguntaDAO.gravar(pergunta10);

    }

}
