package br.com.sqlite.util;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MySQLiteHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "BD_Matemaquiz.db";

    public MySQLiteHelper(Context context){

        super(context, DATABASE_NAME, null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db){

        String createTbPergunta = "CREATE TABLE IF NOT EXISTS tb_pergunta (" + "cod_pergunta integer NOT NULL PRIMARY KEY AUTOINCREMENT," + "titulo varchar(200) NOT NULL," + "cod_questionario integer NOT NULL," + "numero_pergunta int NOT NULL," + "a1 varchar(200) NOT NULL," + "a2 varchar(200) NOT NULL," + "a3 varchar(200) NOT NULL," + "a4 varchar(200) NOT NULL," + "a5 varchar(200) NOT NULL," + "a_correta integer NOT NULL);";
        db.execSQL(createTbPergunta);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){}

}
