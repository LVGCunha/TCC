package br.com.populacoes;

import android.content.Context;

import br.com.sqlite.dao.PerguntaDAO;
import br.com.sqlite.model.Pergunta;

public class PopularRaiz2 {

    public void popularRaiz2(Context context){

        Pergunta pergunta1 = new Pergunta();
        Pergunta pergunta2 = new Pergunta();
        Pergunta pergunta3 = new Pergunta();
        Pergunta pergunta4 = new Pergunta();
        Pergunta pergunta5 = new Pergunta();
        Pergunta pergunta6 = new Pergunta();
        Pergunta pergunta7 = new Pergunta();
        Pergunta pergunta8 = new Pergunta();
        Pergunta pergunta9 = new Pergunta();
        Pergunta pergunta10 = new Pergunta();
        PerguntaDAO perguntaDAO = new PerguntaDAO(context);

        pergunta1.preDados("Qual o valor mais próximo da raiz quadrada de 487?", 4, 1, "24", "23", "22", "21", "Nenhuma das anteriores", 3);
        pergunta2.preDados("Qual o valor mais próximo da raiz quadrada de 376?", 4, 2, "19", "21", "18", "16", "Nenhuma das anteriores", 1);
        pergunta3.preDados("Qual o valor mais próximo da raiz quadrada de 574?", 4, 3, "20", "24", "22", "21", "Nenhuma das anteriores", 2);
        pergunta4.preDados("Qual o valor mais próximo da raiz quadrada de 907?", 4, 4, "34", "32", "31", "30", "Nenhuma das anteriores", 4);
        pergunta5.preDados("Qual o valor mais próximo da raiz quadrada de 666?", 4, 5, "24", "25", "27", "28", "Nenhuma das anteriores", 5);
        pergunta6.preDados("Qual o valor mais próximo da raiz quadrada de 775?", 4, 6, "27", "26", "29", "24", "Nenhuma das anteriores", 5);
        pergunta7.preDados("Qual o valor mais próximo da raiz quadrada de 150?", 4, 7, "10", "11", "13", "12", "Nenhuma das anteriores", 4);
        pergunta8.preDados("Qual o valor mais próximo da raiz quadrada de 284?", 4, 8, "19", "17", "16", "15", "Nenhuma das anteriores", 2);
        pergunta9.preDados("Qual o valor mais próximo da raiz quadrada de 854?", 4, 9, "29", "27", "31", "26", "Nenhuma das anteriores", 1);
        pergunta10.preDados("Qual o valor mais próximo da raiz quadrada de 444?", 4, 10, "24", "23", "21", "22", "Nenhuma das anteriores", 3);

        perguntaDAO.gravar(pergunta1);
        perguntaDAO.gravar(pergunta2);
        perguntaDAO.gravar(pergunta3);
        perguntaDAO.gravar(pergunta4);
        perguntaDAO.gravar(pergunta5);
        perguntaDAO.gravar(pergunta6);
        perguntaDAO.gravar(pergunta7);
        perguntaDAO.gravar(pergunta8);
        perguntaDAO.gravar(pergunta9);
        perguntaDAO.gravar(pergunta10);

    }

}
