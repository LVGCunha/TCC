package br.com.populacoes;

import android.content.Context;

import br.com.sqlite.dao.PerguntaDAO;
import br.com.sqlite.model.Pergunta;

public class PopularFracaoPorcentagem {

    public void popularFracaoPorcentagem(Context context){

        Pergunta pergunta1 = new Pergunta();
        Pergunta pergunta2 = new Pergunta();
        Pergunta pergunta3 = new Pergunta();
        Pergunta pergunta4 = new Pergunta();
        Pergunta pergunta5 = new Pergunta();
        Pergunta pergunta6 = new Pergunta();
        Pergunta pergunta7 = new Pergunta();
        Pergunta pergunta8 = new Pergunta();
        Pergunta pergunta9 = new Pergunta();
        Pergunta pergunta10 = new Pergunta();
        PerguntaDAO perguntaDAO = new PerguntaDAO(context);

        pergunta1.preDados("Qual o valor mais próximo de 1/7?", 5, 1, "12,5%", "15,5%", "14,5%", "13,5%", "Nenhuma das anteriores", 3);
        pergunta2.preDados("Qual o valor mais próximo de 1/6?", 5, 2, "16,5%", "15,5%", "17,5%", "14,5%", "Nenhuma das anteriores", 1);
        pergunta3.preDados("Qual o valor mais próximo de 3/8?", 5, 3, "12,5%", "37,5%", "25,0%", "36,5%", "Nenhuma das anteriores", 2);
        pergunta4.preDados("Qual o valor mais próximo de 1/9?", 5, 4, "10,0%", "12,0%", "11,0%", "9,0%", "Nenhuma das anteriores", 4);
        pergunta5.preDados("Qual o valor mais próximo de 1/12?", 5, 5, "7,5%", "6,5%", "5,5%", "4,4%", "Nenhuma das anteriores", 5);
        pergunta6.preDados("Qual o valor mais próximo de 3/12?", 5, 6, "8,5%", "16,5%", "17,5%", "9,5%", "Nenhuma das anteriores", 5);
        pergunta7.preDados("Qual o valor mais próximo de 1/15?", 5, 7, "5,5%", "8,5%", "7,5%", "6,5%", "Nenhuma das anteriores", 4);
        pergunta8.preDados("Qual o valor mais próximo de 5/15?", 5, 8, "32,5%", "33,5%", "31,5%", "30,0%", "Nenhuma das anteriores", 2);
        pergunta9.preDados("Qual o valor mais próximo de 2/3?", 5, 9, "66,5%", "65,5%", "67,5%", "68,5%", "Nenhuma das anteriores", 1);
        pergunta10.preDados("Qual o valor mais próximo de 2/7?", 5, 10, "26,5%", "29,5%", "28,5%", "27,5%", "Nenhuma das anteriores", 3);

        perguntaDAO.gravar(pergunta1);
        perguntaDAO.gravar(pergunta2);
        perguntaDAO.gravar(pergunta3);
        perguntaDAO.gravar(pergunta4);
        perguntaDAO.gravar(pergunta5);
        perguntaDAO.gravar(pergunta6);
        perguntaDAO.gravar(pergunta7);
        perguntaDAO.gravar(pergunta8);
        perguntaDAO.gravar(pergunta9);
        perguntaDAO.gravar(pergunta10);

    }

}
