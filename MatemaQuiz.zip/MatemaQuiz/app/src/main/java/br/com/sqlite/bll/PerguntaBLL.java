package br.com.sqlite.bll;

import android.content.Context;
import android.database.SQLException;

import br.com.sqlite.dao.PerguntaDAO;
import br.com.sqlite.model.Pergunta;

public class PerguntaBLL {

    protected PerguntaDAO perguntaDAO = null;

    public PerguntaBLL(Context context) {
        perguntaDAO = new PerguntaDAO(context);
    }

    public long gravar(Pergunta pergunta) throws SQLException {
        return perguntaDAO.gravar(pergunta);
    }

    public Pergunta recuperarUm(int cod_pergunta) {
        return perguntaDAO.recuperarUm(cod_pergunta);
    }

}
