package com.example.matemaquiz;

import android.annotation.SuppressLint;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class TelaMetodo extends AppCompatActivity {
    /**
     * Whether or not the system UI should be auto-hidden after
     * {@link #AUTO_HIDE_DELAY_MILLIS} milliseconds.
     */
    private static final boolean AUTO_HIDE = true;

    /**
     * If {@link #AUTO_HIDE} is set, the number of milliseconds to wait after
     * user interaction before hiding the system UI.
     */
    private static final int AUTO_HIDE_DELAY_MILLIS = 0;

    /**
     * Some older devices needs a small delay between UI widget updates
     * and a change of the status and navigation bar.
     */
    private static final int UI_ANIMATION_DELAY = 0;
    private final Handler mHideHandler = new Handler();
    private View mContentView;
    private final Runnable mHidePart2Runnable = new Runnable() {
        @SuppressLint("InlinedApi")
        @Override
        public void run() {
            // Delayed removal of status and navigation bar

            // Note that some of these constants are new as of API 16 (Jelly Bean)
            // and API 19 (KitKat). It is safe to use them, as they are inlined
            // at compile-time and do nothing on earlier devices.
            mContentView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        }
    };
    private View mControlsView;
    private final Runnable mShowPart2Runnable = new Runnable() {
        @Override
        public void run() {
            // Delayed display of UI elements
            ActionBar actionBar = getSupportActionBar();
            if (actionBar != null) {
                actionBar.show();
            }
            mControlsView.setVisibility(View.VISIBLE);
        }
    };
    private boolean mVisible;
    private final Runnable mHideRunnable = new Runnable() {
        @Override
        public void run() {
            hide();
        }
    };
    /**
     * Touch listener to use for in-layout UI controls to delay hiding the
     * system UI. This is to prevent the jarring behavior of controls going away
     * while interacting with activity UI.
     */
    private final View.OnTouchListener mDelayHideTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            switch (motionEvent.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    if (AUTO_HIDE) {
                        delayedHide(AUTO_HIDE_DELAY_MILLIS);
                    }
                    break;
                case MotionEvent.ACTION_UP:
                    view.performClick();
                    break;
                default:
                    break;
            }
            return false;
        }
    };

    private int definidor = 0;
    private TextView txt_Metodo;
    private Intent intent;
    private int dificuldade = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_tela_metodo);

        mVisible = true;
        mControlsView = findViewById(R.id.fullscreen_content_controls);
        mContentView = findViewById(R.id.fullscreen_content);

        // Set up the user interaction to manually show or hide the system UI.
        mContentView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggle();
            }
        });

        // Upon interacting with UI controls, delay any scheduled hide()
        // operations to prevent the jarring behavior of controls going away
        // while interacting with the UI.
        //findViewById(R.id.dummy_button).setOnTouchListener(mDelayHideTouchListener);

        txt_Metodo = (TextView) findViewById(R.id.txt_Metodo);
        txt_Metodo.setFocusable(false);

        intent = getIntent();
        definidor = intent.getIntExtra("definidor", 0);

        manipuladorGeral();

    }

    @Override
    protected void onStart() {
        super.onStart();
        intent = getIntent();
        definidor = intent.getIntExtra("definidor", 0);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        // Trigger the initial hide() shortly after the activity has been
        // created, to briefly hint to the user that UI controls
        // are available.
        delayedHide(0);
    }

    private void toggle() {
        if (mVisible) {
            hide();
        } else {
            //show();
        }
    }

    private void hide() {
        // Hide UI first
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        mControlsView.setVisibility(View.GONE);
        mVisible = false;

        // Schedule a runnable to remove the status and navigation bar after a delay
        mHideHandler.removeCallbacks(mShowPart2Runnable);
        mHideHandler.postDelayed(mHidePart2Runnable, UI_ANIMATION_DELAY);
    }

    private void show() {
        // Show the system bar
        mContentView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        mVisible = true;

        // Schedule a runnable to display UI elements after a delay
        mHideHandler.removeCallbacks(mHidePart2Runnable);
        mHideHandler.postDelayed(mShowPart2Runnable, UI_ANIMATION_DELAY);
    }

    /**
     * Schedules a call to hide() in delay milliseconds, canceling any
     * previously scheduled calls.
     */
    private void delayedHide(int delayMillis) {
        mHideHandler.removeCallbacks(mHideRunnable);
        mHideHandler.postDelayed(mHideRunnable, delayMillis);
    }

    public void manipuladorGeral(){

        if (definidor == 1){

            txt_Metodo.setText("Para realizar operações de soma e subtração de uma maneira mais básica, podemos simplificar os números envolvidos antes de realizar a operação. Exemplo: 147 + 756 --> [(100)+(50-10)+(5+2)] + [(500+200)+(50)+(5+1)] = (100+500+200) + (50-10+50) + (5+2+5+1) = 800+90+13 = 903. Note que, neste exemplo, eu optei por simplificar os números iniciais (147 e 756) de forma com que todos os dígitos ficassem menores que 6 (7 = 5+2; 700 = 500+200). No final, para uma melhor organização e clareza, eu somei primeiramente as centenas, depois as dezenas e então as unidades. Após isso, somei todos os resultados para obter o valor final. Você pode simplificá-los da maneira que mais se sentir confortável, o importante é se atentar à casa que você está simplificando (se são as unidades, dezenas, centenas, etc.). Outro exemplo: 7652 - 149 --> [(5000+2000)+(100+500)+(50)+(2)] - [(0000)+(100)+(50-10)+(10-1)] = (5000+2000-0000) + (100+500-100) + (50-50+10) + (2-10+1) = 7000+500+10-7 = 7503.");
            dificuldade = 1;

        }
        else if (definidor == 2){

            txt_Metodo.setText("Para realizar operações de multiplicação de uma maneira mais básica, podemos simplificar os números envolvidos antes de realizar a operação. Exemplo: 27 x 43 --> [(30-3)] x [(4x10)+(3)] = ({30-3}x4x10) + ({30-3}x3) = 1200-120+90-9 = 1163. Note que, neste exemplo, eu optei por simplificar os números iniciais (147 e 756) de forma diferente: no primeiro, eu simplifiquei todo o número para que não houvesse dígitos maiores que 5 (27 = 30-3), e no segundo, eu simplifiquei separando as casas unitárias (43 = 4*10+3). No final, eu multipliquei o primeiro número (27) pelas dezenas do segundo número e então multipliquei novamente o primeiro número, mas agora pelas unidades do segundo. Após isso, somei todos os resultados para obter o valor final. Você pode simplificá-los da maneira que mais se sentir confortável, o importante é se atentar à casa que você está simplificando (se são as unidades, dezenas, centenas, etc.).");
            dificuldade = 2;

        }
        else if (definidor == 3){

            txt_Metodo.setText("Para elevar números ao quadrado de uma maneira mais básica, podemos utilizar duas fórmulas, onde o x é o nosso número: x² = (2x-1) + (x-1)² ou x² = (x+1)² - [2*(x+1)-1]. Para ficar mais claro, eis um exemplo para cada fórmula: 53² --> (53x2-1) + (52x2-1) + (51x2-1) + 2500 = 2500+101+103+105 = 2809. 58² --> 3600 - (60*2-1) - (59*2-1) = 3364. Você também pode aplicar a técnica da multiplicação ensinada na dificuldade fácil da matéria de Multiplicação. No caso da primeira fórmula, ela também pode simplificá-la, pois há uma sucessão de números ímpares sendo adicionados ao valor de 50² (2500), são eles 101 (51*2-1), 103 (52*2-1) e 105 (53*2-1).");
            dificuldade = 3;

        }
        else if (definidor == 4){

            txt_Metodo.setText("Para se obter a raiz quadrada aproximada de um número de maneira mais prática, precisamos, inicilamente, determinar o intervalo no qual estará o resultado. Então, analisamos qual seria o valor mais próximo deste número dentro deste intervalo. Dependendo do resultado, deverão ser separados os dois primeiros dígitos do número da raiz ou apenas o primeiro número. Com isso, tentamos encontrar qual é o quadrado perfeito mais próximo daquele número e que seja menor ou igual a ele. Assim obtemos o primeiro dígito do número que desejamos. Agora, você pode tanto adaptar os passos anteriores, como usar a técnica de elevar ao quadrado ensinada na dificuldade fácil da matéria de Segunda Potência. Para esclarecer, eis o exemplo: raiz quadrada de 5328 --> 10²=100 < x²=5328 < 100²=10000, estando mais ou menos no meio, logo, x é um número de dois dígitos (pois é maior que 10 e menor que 100) --> Primeiro(s) dígito(s): 5 (valor próximo de 2²) ou 53 (valor próximo de 7²). 7 está mais próximo do meio (ou seja, de 5) e 7² é menor ou igual a 53, logo, 7 é o primeiro dígito --> 70² = 49000, 80² = 64000, sendo que 5328 está mais próximo de 70², logo, o segundo e último dígito é um valor pequeno --> Utilizando a técnica da Segunda Potência, 71² = 4900+141 = 5041, 72² = 5041+143 = 5184, 73² = 5184+145 = 5329. Note que 5328 é extremamente próximo de 5329, logo, x é igual a, aproximadamente, 73. Perceba também que este método permite apenas a obtenção de valores aproximados, ou seja, ele não pode ser aplicado para a obtenção de valores exatos.");
            dificuldade = 4;

        }
        else if (definidor == 5){

            txt_Metodo.setText("Para se converter uma fração para porcentagem de maneira aproximada e mais prática, precisamos, antes de tudo, ter em mente os casos mais básicos e fundamentais, como 1/2 (50%), 1/3 (33,33%) e 1/5 (20%). Com isso, podemos converter mais facilmente quase qualquer fração. Para isso, deve-se utilizar a divisão e a subtração como o exemplo a seguir demostra: 8/29 --> (1/3)/10 = 1/30, 33,33/10 = 3,333; (1/2)/14 = 1/28, 50/14 = 3,571. Logo, 3,571>1/29>3,333 --> 3,571-3,333 = 0,238, 0,238/2 = 0,119 --> 3,571-0,119 = 3,452 --> 3,452*8 = 27,616 --> Logo, 8/29 é aproximadamente 27,6%. Quanto mais casas decimais forem consideradas, mais preciso será o seu resultado, embora não haja garantia de que ele seja totalmente preciso.");
            dificuldade = 5;

        }
        else if (definidor == 0){

            txt_Metodo.setText("");

        }

    }

    public void passarTelaMetodoQuestionario(View view){

        Intent intent = new Intent(TelaMetodo.this, TelaQuestionario.class);
        intent.putExtra("tema", definidor);
        intent.putExtra("dificuldade", dificuldade);
        definidor = 0;
        dificuldade = 0;
        manipuladorGeral();
        startActivity(intent);

    }

    public void passarTelaMenuPrincipal(View view){

        Intent intent = new Intent(TelaMetodo.this, TelaMenuPrincipal.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        manipuladorGeral();
        startActivity(intent);

    }

}