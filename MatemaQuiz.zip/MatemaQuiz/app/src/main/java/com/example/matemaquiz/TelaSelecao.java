package com.example.matemaquiz;

import android.annotation.SuppressLint;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class TelaSelecao extends AppCompatActivity {
    /**
     * Whether or not the system UI should be auto-hidden after
     * {@link #AUTO_HIDE_DELAY_MILLIS} milliseconds.
     */
    private static final boolean AUTO_HIDE = true;

    /**
     * If {@link #AUTO_HIDE} is set, the number of milliseconds to wait after
     * user interaction before hiding the system UI.
     */
    private static final int AUTO_HIDE_DELAY_MILLIS = 0;

    /**
     * Some older devices needs a small delay between UI widget updates
     * and a change of the status and navigation bar.
     */
    private static final int UI_ANIMATION_DELAY = 0;
    private final Handler mHideHandler = new Handler();
    private View mContentView;
    private final Runnable mHidePart2Runnable = new Runnable() {
        @SuppressLint("InlinedApi")
        @Override
        public void run() {
            // Delayed removal of status and navigation bar

            // Note that some of these constants are new as of API 16 (Jelly Bean)
            // and API 19 (KitKat). It is safe to use them, as they are inlined
            // at compile-time and do nothing on earlier devices.
            mContentView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        }
    };
    private View mControlsView;
    private final Runnable mShowPart2Runnable = new Runnable() {
        @Override
        public void run() {
            // Delayed display of UI elements
            ActionBar actionBar = getSupportActionBar();
            if (actionBar != null) {
                actionBar.show();
            }
            mControlsView.setVisibility(View.VISIBLE);
        }
    };
    private boolean mVisible;
    private final Runnable mHideRunnable = new Runnable() {
        @Override
        public void run() {
            hide();
        }
    };
    /**
     * Touch listener to use for in-layout UI controls to delay hiding the
     * system UI. This is to prevent the jarring behavior of controls going away
     * while interacting with activity UI.
     */
    private final View.OnTouchListener mDelayHideTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            switch (motionEvent.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    if (AUTO_HIDE) {
                        delayedHide(AUTO_HIDE_DELAY_MILLIS);
                    }
                    break;
                case MotionEvent.ACTION_UP:
                    view.performClick();
                    break;
                default:
                    break;
            }
            return false;
        }
    };

    private int indice = 0;
    private int subIndice = 0;
    private int auxSubIndice = 0;
    private int subIndice2 = 0;
    private  int auxSubIndice2 = 0;
    private int auxAuxSubIndice = 0;

    private Button botao1;
    private Button botao2;
    private Button botao3;
    private Button botao4;
    private Button botao5;
    private TextView voltar;
    private TextView tituloSelecao;

    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_tela_selecao);

        mVisible = true;
        mControlsView = findViewById(R.id.fullscreen_content_controls);
        mContentView = findViewById(R.id.fullscreen_content);

        // Set up the user interaction to manually show or hide the system UI.
        mContentView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggle();
            }
        });

        // Upon interacting with UI controls, delay any scheduled hide()
        // operations to prevent the jarring behavior of controls going away
        // while interacting with the UI.
        //findViewById(R.id.dummy_button).setOnTouchListener(mDelayHideTouchListener);

        botao1 = (Button)findViewById(R.id.btn_Selecao1);
        botao2 = (Button)findViewById(R.id.btn_Selecao2);
        botao3 = (Button)findViewById(R.id.btn_Selecao3);
        botao4 = (Button)findViewById(R.id.btn_Selecao4);
        botao5 = (Button)findViewById(R.id.btn_Selecao5);
        voltar = (TextView)findViewById(R.id.txt_voltarSelecao);
        tituloSelecao = (TextView)findViewById(R.id.txt_TituloSelecao);

        Intent intent = getIntent();
        indice = intent.getIntExtra("valorIndice", 0);

        manipuladorGeral();

    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        // Trigger the initial hide() shortly after the activity has been
        // created, to briefly hint to the user that UI controls
        // are available.
        delayedHide(0);
    }

    private void toggle() {
        if (mVisible) {
            hide();
        } else {
            //show();
        }
    }

    private void hide() {
        // Hide UI first
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        mControlsView.setVisibility(View.GONE);
        mVisible = false;

        // Schedule a runnable to remove the status and navigation bar after a delay
        mHideHandler.removeCallbacks(mShowPart2Runnable);
        mHideHandler.postDelayed(mHidePart2Runnable, UI_ANIMATION_DELAY);
    }

    private void show() {
        // Show the system bar
        mContentView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        mVisible = true;

        // Schedule a runnable to display UI elements after a delay
        mHideHandler.removeCallbacks(mHidePart2Runnable);
        mHideHandler.postDelayed(mShowPart2Runnable, UI_ANIMATION_DELAY);
    }

    /**
     * Schedules a call to hide() in delay milliseconds, canceling any
     * previously scheduled calls.
     */
    private void delayedHide(int delayMillis) {
        mHideHandler.removeCallbacks(mHideRunnable);
        mHideHandler.postDelayed(mHideRunnable, delayMillis);
    }

    //--------------------------------------------

    public void manipuladorGeral(){

        if(indice == 1 && subIndice == 0 && subIndice2 == 0){

            tituloSelecao.setText("Seleção de disciplina");

            botao1.setClickable(true);
            botao1.setVisibility(View.VISIBLE);
            botao1.setText("Matemática");

            botao2.setClickable(false);
            botao2.setVisibility(View.GONE);
            botao3.setClickable(false);
            botao3.setVisibility(View.GONE);
            botao4.setClickable(false);
            botao4.setVisibility(View.GONE);
            botao5.setClickable(false);
            botao5.setVisibility(View.GONE);

        }

        //------------------------------------------------------

        else if (subIndice == 0 && subIndice2 == 0){

            tituloSelecao.setText("Seleção de disciplina");

            botao1.setClickable(true);
            botao1.setVisibility(View.VISIBLE);
            botao1.setText("Matemática");

            botao2.setClickable(false);
            botao2.setVisibility(View.GONE);
            botao3.setClickable(false);
            botao3.setVisibility(View.GONE);
            botao4.setClickable(false);
            botao4.setVisibility(View.GONE);
            botao5.setClickable(false);
            botao5.setVisibility(View.GONE);

        }
        else if (subIndice == 1 && subIndice2 == 0){

            tituloSelecao.setText("Seleção de matéria");

            botao1.setClickable(true);
            botao1.setVisibility(View.VISIBLE);
            botao1.setText("Soma e subtração");

            botao2.setClickable(true);
            botao2.setVisibility(View.VISIBLE);
            botao2.setText("Multiplicação");

            botao3.setClickable(true);
            botao3.setVisibility(View.VISIBLE);
            botao3.setText("Segunda potência");

            botao4.setClickable(true);
            botao4.setVisibility(View.VISIBLE);
            botao4.setText("Raiz quadrada");

            botao5.setClickable(true);
            botao5.setVisibility(View.VISIBLE);
            botao5.setText("Fração e porcentagem");

        }

        //-----------------------------------------------

        else if (subIndice2 == 1){

            tituloSelecao.setText("Seleção de dificuldade");

            botao1.setClickable(true);
            botao1.setVisibility(View.VISIBLE);
            botao1.setText("Fácil");

            botao2.setClickable(false);
            botao2.setVisibility(View.GONE);
            botao3.setClickable(false);
            botao3.setVisibility(View.GONE);
            botao4.setClickable(false);
            botao4.setVisibility(View.GONE);
            botao5.setClickable(false);
            botao5.setVisibility(View.GONE);

        }
        else if (subIndice2 == 2){

            tituloSelecao.setText("Seleção de dificuldade");

            botao1.setClickable(true);
            botao1.setVisibility(View.VISIBLE);
            botao1.setText("Fácil");

            botao2.setClickable(false);
            botao2.setVisibility(View.GONE);
            botao3.setClickable(false);
            botao3.setVisibility(View.GONE);
            botao4.setClickable(false);
            botao4.setVisibility(View.GONE);
            botao5.setClickable(false);
            botao5.setVisibility(View.GONE);

        }
        else if (subIndice2 == 3){

            tituloSelecao.setText("Seleção de dificuldade");

            botao1.setClickable(true);
            botao1.setVisibility(View.VISIBLE);
            botao1.setText("Fácil");

            botao2.setClickable(false);
            botao2.setVisibility(View.GONE);
            botao3.setClickable(false);
            botao3.setVisibility(View.GONE);
            botao4.setClickable(false);
            botao4.setVisibility(View.GONE);
            botao5.setClickable(false);
            botao5.setVisibility(View.GONE);

        }
        else if (subIndice2 == 4){

            tituloSelecao.setText("Seleção de dificuldade");

            botao1.setClickable(true);
            botao1.setVisibility(View.VISIBLE);
            botao1.setText("Fácil");

            botao2.setClickable(false);
            botao2.setVisibility(View.GONE);
            botao3.setClickable(false);
            botao3.setVisibility(View.GONE);
            botao4.setClickable(false);
            botao4.setVisibility(View.GONE);
            botao5.setClickable(false);
            botao5.setVisibility(View.GONE);

        }
        else if (subIndice2 == 5){

            tituloSelecao.setText("Seleção de dificuldade");

            botao1.setClickable(true);
            botao1.setVisibility(View.VISIBLE);
            botao1.setText("Fácil");

            botao2.setClickable(false);
            botao2.setVisibility(View.GONE);
            botao3.setClickable(false);
            botao3.setVisibility(View.GONE);
            botao4.setClickable(false);
            botao4.setVisibility(View.GONE);
            botao5.setClickable(false);
            botao5.setVisibility(View.GONE);

        }

    }

    public void manipuladorBotao1(View view){

        if (indice == 1 && subIndice == 0){

            auxAuxSubIndice = auxSubIndice;
            auxSubIndice = subIndice;
            subIndice = 1;
            manipuladorGeral();

        }
        else if (subIndice == 1 && subIndice2 == 0){

            auxSubIndice = subIndice;
            subIndice = 1;
            auxSubIndice2 = subIndice2;
            subIndice2 = 1;
            manipuladorGeral();

        }
        else if (subIndice2 != 0){

            intent = new Intent(TelaSelecao.this, TelaMetodo.class);
            intent.putExtra("definidor", subIndice2);
            indice = 1;
            subIndice = 0;
            auxSubIndice = 0;
            auxAuxSubIndice = 0;
            subIndice2 = 0;
            auxSubIndice2 = 0;
            manipuladorGeral();
            startActivity(intent);

        }


        /*if (subIndice == 2){}
        if (subIndice == 3){}
        if (subIndice == 4){}
        if (subIndice == 5){}*/

    }

    public void manipuladorBotao2(View view){

        /*if (indice == 1 && subIndice == 0){

            auxSubIndice = subIndice;
            subIndice = 2;
            manipuladorGeral();

        }*/

        if (subIndice == 1){

            auxSubIndice = subIndice;
            subIndice = 1;
            auxSubIndice2 = subIndice2;
            subIndice2 = 2;
            manipuladorGeral();

        }

        /*if (subIndice == 2){}
        if (subIndice == 3){}
        if (subIndice == 4){}
        if (subIndice == 5){}*/

    }

    public void manipuladorBotao3(View view){

        /*if (indice == 1 && subIndice == 0){

            auxSubIndice = subIndice;
            subIndice = 3;
            manipuladorGeral();

        }*/

        if (subIndice == 1){

            auxSubIndice = subIndice;
            subIndice = 1;
            auxSubIndice2 = subIndice2;
            subIndice2 = 3;
            manipuladorGeral();

        }

        /*if (subIndice == 2){}
        if (subIndice == 3){}
        if (subIndice == 4){}
        if (subIndice == 5){}*/

    }

    public void manipuladorBotao4(View view){

        /*if (indice == 1 && subIndice == 0){

            auxSubIndice = subIndice;
            subIndice = 4;
            manipuladorGeral();

        }*/

        if (subIndice == 1){

            auxSubIndice = subIndice;
            subIndice = 1;
            auxSubIndice2 = subIndice2;
            subIndice2 = 4;
            manipuladorGeral();

        }

        /*if (subIndice == 2){}
        if (subIndice == 3){}
        if (subIndice == 4){}
        if (subIndice == 5){}*/

    }

    public void manipuladorBotao5(View view){

        /*if (indice == 1 && subIndice == 0){

            auxSubIndice = subIndice;
            subIndice = 5;
            manipuladorGeral();

        }*/

        if (subIndice == 1){

            auxSubIndice = subIndice;
            subIndice = 1;
            auxSubIndice2 = subIndice2;
            subIndice2 = 5;
            manipuladorGeral();

        }

        /*if (subIndice == 2){}
        if (subIndice == 3){}
        if (subIndice == 4){}
        if (subIndice == 5){}*/

    }

    public void manipuladorVoltar(View view){

        if (indice == 1 && subIndice == 0){

            Intent intent = new Intent(TelaSelecao.this, TelaMenuPrincipal.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(intent);

        }

        if(subIndice != 0){

            subIndice = auxSubIndice;
            auxSubIndice = auxAuxSubIndice;
            manipuladorGeral();

        }

        if (subIndice2 != 0){

            subIndice2 = auxSubIndice2;
            manipuladorGeral();

        }

    }



    //--------------------------------------------

    public void passarTelaMenuPrincipal(View view){

        subIndice = 0;
        subIndice2 = 0;
        manipuladorGeral();

        Intent intent = new Intent(TelaSelecao.this, TelaMenuPrincipal.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);

    }

}